import React from "react";
import { Link } from "react-router-dom";
import "./Home.css";
import homeimg from "../assets/image.png";

function Home() {

    const homeStyle = {
        margin: "0",
        padding: "0",
        fontFamily: "Arial, sans-serif",
        minHeight: "100vh",
        width: "100%",
        overflow: "hidden"
    };

    const headerStyle = {
        backgroundColor: "white",
        padding: "10px 20px",
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        position: "fixed",
        top: 0,
        left: 0,
        zIndex: 10,
        width: "100%",
        boxSizing: "border-box"
    };

    const heading = {
        background: "linear-gradient(to right, #3bd5f7, #fc30fc)",
        WebkitBackgroundClip: "text",
        WebkitTextFillColor: "transparent",
        fontSize: "45px",
        fontWeight: "bold"
    };

    const navbarStyle = {
        display: "flex",
        gap: "25px",
        fontSize: "24px",
        fontWeight: "bold",
        alignItems: "center"
    };

    const linkStyle = {
        textDecoration: "none",
        fontSize: "18px",
        fontWeight: "600"
    };

    const content = {
        textAlign: "center"
    };

    return (

        <div
            className="home-container"
            style={homeStyle}
        >

            {/* NAVBAR */}

            <div style={headerStyle}>

                <h1
                    className="heading"
                    style={heading}
                >
                    EduLentra
                </h1>


                <nav
                    className="navbar"
                    style={navbarStyle}
                >

                    <a
                        href="/"
                        style={linkStyle}
                    >
                        Home
                    </a>

                    <a
                        href="#about"
                        style={linkStyle}
                    >
                        About
                    </a>

                    <a
                        href="#highlights"
                        style={linkStyle}
                    >
                        Highlights
                    </a>

                    <a
                        href="#gallery"
                        style={linkStyle}
                    >
                        Gallery
                    </a>


                    <a
                        href="#login"
                        style={linkStyle}
                    >
                        Login
                    </a>


                    <a
                        href="#contact"
                        style={linkStyle}
                    >
                        Contact
                    </a>


                    {/* GET STARTED */}

                    <Link
                        to="/roles"
                        className="get-started-btn"
                    >
                        Get Started
                    </Link>

                </nav>

            </div>


            {/* HOME IMAGE */}

            <div
                className="content"
                style={content}
            >

                <img
                    src={homeimg}
                    alt="Education"
                    className="home-image"
                />

            </div>

        </div>
    );
}

export default Home;