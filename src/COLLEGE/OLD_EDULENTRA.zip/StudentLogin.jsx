import React, { useState } from "react";
import "./StudentLogin.css";

import bookCover from "../assets/book-cover.png";
import goldKey from "../assets/gold-key.png";
import paper from "../assets/paper.png";

function StudentLogin() {

    const [openBook, setOpenBook] = useState(false);
    const [rotateKey, setRotateKey] = useState(false);
    const [showSignup, setShowSignup] = useState(false);

    const [loginData, setLoginData] = useState({
        rollNumber: "",
        password: ""
    });

    const [signupData, setSignupData] = useState({
        name: "",
        rollNumber: "",
        email: "",
        department: "",
        branch: "",
        password: "",
        confirmPassword: ""
    });


    /* OPEN BOOK */

    const unlockBook = () => {

        if (openBook) {
            return;
        }

        setRotateKey(true);

        setTimeout(() => {
            setOpenBook(true);
        }, 1000);
    };


    /* LOGIN */

    const handleLogin = (e) => {

        e.preventDefault();

        if (!loginData.rollNumber || !loginData.password) {

            alert("Please enter Roll Number and Password.");

            return;
        }

        alert("Login successful!");
    };


    /* SIGNUP */

    const handleSignup = (e) => {

        e.preventDefault();

        if (
            !signupData.name ||
            !signupData.rollNumber ||
            !signupData.email ||
            !signupData.department ||
            !signupData.branch ||
            !signupData.password ||
            !signupData.confirmPassword
        ) {

            alert("Please fill all the fields.");

            return;
        }


        if (
            signupData.password !==
            signupData.confirmPassword
        ) {

            alert("Passwords do not match.");

            return;
        }

        alert("Registration successful!");

        setShowSignup(false);
    };


    return (

        <div className="student-login-page">

            <h1>
                Student Portal
            </h1>


            {/* BOOK */}

            <div
                className={`student-book ${
                    openBook ? "book-open" : ""
                }`}
            >


                {/* INSIDE PAPER */}

                <div
                    className="student-inside-page"
                    style={{
                        backgroundImage:
                            `url(${paper})`
                    }}
                >


                    {/* LOGIN */}

                    {!showSignup && (

                        <div className="student-form">

                            <h2>
                                Student Login
                            </h2>


                            <form
                                onSubmit={handleLogin}
                            >

                                <input
                                    type="text"
                                    placeholder="Enter Roll Number"
                                    value={
                                        loginData.rollNumber
                                    }
                                    onChange={(e) =>
                                        setLoginData({
                                            ...loginData,
                                            rollNumber:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="password"
                                    placeholder="Enter Password"
                                    value={
                                        loginData.password
                                    }
                                    onChange={(e) =>
                                        setLoginData({
                                            ...loginData,
                                            password:
                                                e.target.value
                                        })
                                    }
                                />


                                <button type="submit">
                                    Login
                                </button>

                            </form>


                            <p className="student-account-text">
                                Don't have an account?
                            </p>


                            <button
                                type="button"
                                className="student-secondary-btn"
                                onClick={() =>
                                    setShowSignup(true)
                                }
                            >
                                Sign Up
                            </button>

                        </div>

                    )}


                    {/* SIGNUP */}

                    {showSignup && (

                        <div className="student-form student-signup-form">

                            <h2>
                                Student Registration
                            </h2>


                            <form
                                onSubmit={handleSignup}
                            >

                                <input
                                    type="text"
                                    placeholder="Full Name"
                                    value={
                                        signupData.name
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            name:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="text"
                                    placeholder="Roll Number"
                                    value={
                                        signupData.rollNumber
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            rollNumber:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="email"
                                    placeholder="Email ID"
                                    value={
                                        signupData.email
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            email:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="text"
                                    placeholder="Department"
                                    value={
                                        signupData.department
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            department:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="text"
                                    placeholder="Branch"
                                    value={
                                        signupData.branch
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            branch:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="password"
                                    placeholder="Create Password"
                                    value={
                                        signupData.password
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            password:
                                                e.target.value
                                        })
                                    }
                                />


                                <input
                                    type="password"
                                    placeholder="Confirm Password"
                                    value={
                                        signupData.confirmPassword
                                    }
                                    onChange={(e) =>
                                        setSignupData({
                                            ...signupData,
                                            confirmPassword:
                                                e.target.value
                                        })
                                    }
                                />


                                <button type="submit">
                                    Register
                                </button>

                            </form>


                            <p className="student-account-text">
                                Already have an account?
                            </p>


                            <button
                                type="button"
                                className="student-secondary-btn"
                                onClick={() =>
                                    setShowSignup(false)
                                }
                            >
                                Login
                            </button>

                        </div>

                    )}

                </div>


                {/* BOOK COVER */}

                <div className="student-book-cover">

                    <img
                        src={bookCover}
                        alt="Student Book Cover"
                        className="student-cover-image"
                    />


                    {/* BOOK SPINE */}

                    <div className="student-book-spine"></div>


                    {/* KEY */}

                    <img
                        src={goldKey}
                        alt="Golden Key"
                        className={
                            rotateKey
                                ? "student-key key-rotate"
                                : "student-key"
                        }
                        onClick={unlockBook}
                    />

                </div>

            </div>


            {/* INSTRUCTION */}

            {!openBook && (

                <p className="student-instruction">
                    Click the key to unlock your book
                </p>

            )}

        </div>
    );
}

export default StudentLogin;