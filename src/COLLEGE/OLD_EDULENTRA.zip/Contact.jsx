import "./Contact.css";

function Contact() {
  return (
    <section className="contact-section" id="contact">

      <h2>Contact Us</h2>
      <p className="contact-intro">
        Meet the team behind <strong>EduLentra</strong>. Feel free to reach out to us for any queries or feedback.
      </p>

      <div className="contact-cards">

        <div className="contact-card">
          <h3>👩 Member 1</h3>
          <p><strong>Role:</strong> Frontend Developer</p>
          <p>📧 member1@gmail.com</p>
          <p>📞 +91 98765 43210</p>
        </div>

        <div className="contact-card">
          <h3>👩 Member 2</h3>
          <p><strong>Role:</strong> Backend Developer</p>
          <p>📧 member2@gmail.com</p>
          <p>📞 +91 98765 43211</p>
        </div>

        <div className="contact-card">
          <h3>👩 Member 3</h3>
          <p><strong>Role:</strong> Database Designer</p>
          <p>📧 member3@gmail.com</p>
          <p>📞 +91 98765 43212</p>
        </div>

        <div className="contact-card">
          <h3>👩 Member 4</h3>
          <p><strong>Role:</strong> UI/UX Designer</p>
          <p>📧 member4@gmail.com</p>
          <p>📞 +91 98765 43213</p>
        </div>

      </div>

      <div className="contact-bottom">
        <div>
          <h4>EduLentra</h4>
          <p>Smart Campus Management System</p>
        </div>

        <div>
          <h4>Quick Links</h4>
          <p>Home | About | Highlights | Login | Contact</p>
        </div>

        <div>
          <h4>Address</h4>
          <p>VEMU IT</p>
          <p>Chittoor, AP</p>
        </div>
      </div>

      <hr />

      <p className="copyright">
        &copy; 2026 EduLentra. All Rights Reserved.
      </p>

    </section>
  );
}

export default Contact;