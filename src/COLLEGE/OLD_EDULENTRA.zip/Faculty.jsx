import React, { useEffect, useState } from "react";
import "./Faculty.css";

function Faculty() {

    const message = "Welcome Faculty";

    const [text, setText] = useState(message);
    const [moveDuster, setMoveDuster] = useState(false);
    const [showPortal, setShowPortal] = useState(false);
    const [page, setPage] = useState("portal");
    const [showPassword, setShowPassword] = useState(false);

    const [loginData, setLoginData] = useState({
        email: "",
        password: ""
    });

    const [signupData, setSignupData] = useState({
        name: "",
        id: "",
        department: "",
        branch: ""
    });


    /* -----------------------------
       WELCOME CHALK ANIMATION
    ----------------------------- */

    useEffect(() => {

        let eraseTimer = null;
        let portalTimer = null;

        const startTimer = setTimeout(() => {

            setMoveDuster(true);

            let index = 0;

            eraseTimer = setInterval(() => {

                index++;

                setText(message.substring(index));

                if (index >= message.length) {

                    clearInterval(eraseTimer);

                    portalTimer = setTimeout(() => {
                        setShowPortal(true);
                    }, 500);

                }

            }, 120);

        }, 2000);


        return () => {

            clearTimeout(startTimer);

            if (eraseTimer) {
                clearInterval(eraseTimer);
            }

            if (portalTimer) {
                clearTimeout(portalTimer);
            }

        };

    }, []);


    /* -----------------------------
       LOGIN
    ----------------------------- */

    function handleLogin(e) {

        e.preventDefault();

        const emailPattern =
            /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        const passwordPattern =
            /^(?=.*[A-Z])(?=.*[0-9]).{8,}$/;


        if (!emailPattern.test(loginData.email)) {

            alert("Please enter a valid faculty email.");

            return;

        }


        if (!passwordPattern.test(loginData.password)) {

            alert(
                "Password must contain at least 8 characters, one capital letter and one number."
            );

            return;

        }


        alert("Login successful after approval.");

    }


    /* -----------------------------
       SIGN UP
    ----------------------------- */

    function handleSignup(e) {

        e.preventDefault();

        if (
            !signupData.name ||
            !signupData.id ||
            !signupData.department ||
            !signupData.branch
        ) {

            alert("Please fill all faculty details.");

            return;

        }


        alert(
            "Faculty registration request sent to HOD/Admin for approval."
        );

    }


    /* -----------------------------
       GO BACK
    ----------------------------- */

    function goBack() {

        setPage("portal");

        setShowPassword(false);

    }


    return (

        <div className="faculty-page">


            {/* PAGE TITLE */}

            <h1 className="faculty-title">
                Faculty Portal
            </h1>



            {/* BLACKBOARD */}

            <div className="faculty-blackboard">


                {/* -----------------------------
                   WELCOME ANIMATION
                ----------------------------- */}

                {!showPortal && (

                    <>

                        <div className="faculty-chalk-text">
                            {text}
                        </div>


                        <div
                            className={
                                `faculty-duster ${
                                    moveDuster ? "move" : ""
                                }`
                            }
                        >
                        </div>


                        <div className="faculty-chalk-tray">

                            <div className="faculty-chalk">
                            </div>

                        </div>

                    </>

                )}



                {/* -----------------------------
                   FACULTY PORTAL
                ----------------------------- */}

                {showPortal && page === "portal" && (

                    <div className="faculty-screen">


                        <div className="chalk-small">
                            FACULTY ACCESS
                        </div>


                        <h2 className="faculty-portal-heading">
                            Faculty Access Portal
                        </h2>


                        <p className="faculty-portal-subtitle">
                            Authorized faculty members only
                        </p>


                        <div className="faculty-option-container">


                            <button
                                type="button"
                                className="faculty-option-btn"
                                onClick={() => setPage("login")}
                            >

                                <span className="faculty-option-icon">
                                    👨‍🏫
                                </span>

                                <span>
                                    Faculty Login
                                </span>

                            </button>


                            <button
                                type="button"
                                className="faculty-option-btn"
                                onClick={() => setPage("signup")}
                            >

                                <span className="faculty-option-icon">
                                    📝
                                </span>

                                <span>
                                    New Faculty Registration
                                </span>

                            </button>


                        </div>

                    </div>

                )}



                {/* -----------------------------
                   LOGIN PAGE
                ----------------------------- */}

                {showPortal && page === "login" && (

                    <div className="faculty-screen login-screen">


                        <div className="chalk-small">
                            FACULTY LOGIN
                        </div>


                        <h2 className="faculty-portal-heading">
                            Welcome Back
                        </h2>


                        <p className="faculty-portal-subtitle">
                            Sign in to your faculty account
                        </p>


                        <form
                            className="faculty-form"
                            onSubmit={handleLogin}
                        >


                            <div className="faculty-input-group">

                                <label>
                                    Faculty Email
                                </label>

                                <input
                                    type="email"
                                    placeholder="Enter faculty email"
                                    value={loginData.email}
                                    onChange={(e) =>
                                        setLoginData({
                                            ...loginData,
                                            email: e.target.value
                                        })
                                    }
                                    required
                                />

                            </div>



                            <div className="faculty-input-group">

                                <label>
                                    Password
                                </label>


                                <div className="password-wrapper">

                                    <input
                                        type={
                                            showPassword
                                                ? "text"
                                                : "password"
                                        }
                                        placeholder="Enter password"
                                        value={loginData.password}
                                        onChange={(e) =>
                                            setLoginData({
                                                ...loginData,
                                                password: e.target.value
                                            })
                                        }
                                        required
                                    />


                                    <button
                                        type="button"
                                        className="password-toggle"
                                        onClick={() =>
                                            setShowPassword(!showPassword)
                                        }
                                    >
                                        {showPassword ? "🙈" : "👁"}
                                    </button>

                                </div>

                            </div>



                            <button
                                type="submit"
                                className="faculty-main-btn"
                            >
                                Login
                            </button>


                            <button
                                type="button"
                                className="faculty-back-btn"
                                onClick={goBack}
                            >
                                ← Back to Faculty Portal
                            </button>


                        </form>

                    </div>

                )}



                {/* -----------------------------
                   SIGNUP PAGE
                ----------------------------- */}

                {showPortal && page === "signup" && (

                    <div className="faculty-screen signup-screen">


                        <div className="chalk-small">
                            FACULTY REGISTRATION
                        </div>


                        <h2 className="faculty-portal-heading">
                            Join Faculty Portal
                        </h2>


                        <p className="faculty-portal-subtitle">
                            Registration requires HOD/Admin approval
                        </p>


                        <form
                            className="faculty-form signup-form"
                            onSubmit={handleSignup}
                        >


                            <div className="faculty-input-row">


                                <div className="faculty-input-group">

                                    <label>
                                        Faculty Name
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Enter name"
                                        value={signupData.name}
                                        onChange={(e) =>
                                            setSignupData({
                                                ...signupData,
                                                name: e.target.value
                                            })
                                        }
                                        required
                                    />

                                </div>



                                <div className="faculty-input-group">

                                    <label>
                                        Faculty ID
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Enter ID"
                                        value={signupData.id}
                                        onChange={(e) =>
                                            setSignupData({
                                                ...signupData,
                                                id: e.target.value
                                            })
                                        }
                                        required
                                    />

                                </div>


                            </div>



                            <div className="faculty-input-row">


                                <div className="faculty-input-group">

                                    <label>
                                        Department
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Enter department"
                                        value={signupData.department}
                                        onChange={(e) =>
                                            setSignupData({
                                                ...signupData,
                                                department: e.target.value
                                            })
                                        }
                                        required
                                    />

                                </div>



                                <div className="faculty-input-group">

                                    <label>
                                        Branch
                                    </label>

                                    <input
                                        type="text"
                                        placeholder="Class teacher branch"
                                        value={signupData.branch}
                                        onChange={(e) =>
                                            setSignupData({
                                                ...signupData,
                                                branch: e.target.value
                                            })
                                        }
                                        required
                                    />

                                </div>


                            </div>



                            <button
                                type="submit"
                                className="faculty-main-btn"
                            >
                                Send Registration Request
                            </button>


                            <button
                                type="button"
                                className="faculty-back-btn"
                                onClick={goBack}
                            >
                                ← Back to Faculty Portal
                            </button>


                        </form>

                    </div>

                )}



                {/* CHALK TRAY */}

                {showPortal && (

                    <div className="faculty-chalk-tray">

                        <div className="faculty-chalk">
                        </div>

                    </div>

                )}

            </div>

        </div>

    );

}

export default Faculty;