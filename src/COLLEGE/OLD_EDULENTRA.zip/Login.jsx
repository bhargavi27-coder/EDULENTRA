import React from "react";
import { Link } from "react-router-dom";
import "./Login.css";

function Login() {

    return (

        <section
            className="login-section"
            id="login"
        >

            <h1>
                Login Portal
            </h1>

            <p className="login-text">
                Select your role to access the EduLentra portal.
            </p>


            <div className="cards">


                {/* ADMIN */}

                <Link
                    to="/roles"
                    className="card"
                >

                    <div className="card-inner">

                        <div className="card-front">

                            <h3>
                                👨‍💼
                            </h3>

                            <h2>
                                Admin Login
                            </h2>

                        </div>


                        <div className="card-back">

                            <h3>
                                Admin Login
                            </h3>

                            <ol>

                                <li>
                                    Click Admin Login.
                                </li>

                                <li>
                                    Enter Admin ID.
                                </li>

                                <li>
                                    Enter Password.
                                </li>

                                <li>
                                    Click Login.
                                </li>

                            </ol>

                        </div>

                    </div>

                </Link>


                {/* HOD */}

                <Link
                    to="/roles"
                    className="card"
                >

                    <div className="card-inner">

                        <div className="card-front">

                            <h3>
                                🎓
                            </h3>

                            <h2>
                                HoD Login
                            </h2>

                        </div>


                        <div className="card-back">

                            <h3>
                                HoD Login
                            </h3>

                            <ol>

                                <li>
                                    Select HoD Login.
                                </li>

                                <li>
                                    Enter HoD ID.
                                </li>

                                <li>
                                    Enter Password.
                                </li>

                                <li>
                                    Click Login.
                                </li>

                            </ol>

                        </div>

                    </div>

                </Link>


                {/* FACULTY */}

                <Link
                    to="/roles"
                    className="card"
                >

                    <div className="card-inner">

                        <div className="card-front">

                            <h3>
                                👩‍🏫
                            </h3>

                            <h2>
                                Faculty Login
                            </h2>

                        </div>


                        <div className="card-back">

                            <h3>
                                Faculty Login
                            </h3>

                            <ol>

                                <li>
                                    Select Faculty Login.
                                </li>

                                <li>
                                    Enter Faculty ID.
                                </li>

                                <li>
                                    Enter Password.
                                </li>

                                <li>
                                    Click Login.
                                </li>

                            </ol>

                        </div>

                    </div>

                </Link>


                {/* STUDENT */}

                <Link
                    to="/roles"
                    className="card"
                >

                    <div className="card-inner">

                        <div className="card-front">

                            <h3>
                                👨‍🎓
                            </h3>

                            <h2>
                                Student Login
                            </h2>

                        </div>


                        <div className="card-back">

                            <h3>
                                Student Login
                            </h3>

                            <ol>

                                <li>
                                    Click Student Login.
                                </li>

                                <li>
                                    Enter Roll Number.
                                </li>

                                <li>
                                    Enter Password.
                                </li>

                                <li>
                                    Click Login.
                                </li>

                            </ol>

                        </div>

                    </div>

                </Link>

            </div>

        </section>
    );
}

export default Login;