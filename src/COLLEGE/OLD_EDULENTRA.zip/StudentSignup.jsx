import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

import "./StudentSignup.css";

function StudentSignup() {

    const navigate = useNavigate();

    const [formData, setFormData] = useState({
        name: "",
        rollNumber: "",
        email: "",
        password: "",
        confirmPassword: ""
    });


    const handleChange = (e) => {

        setFormData({
            ...formData,
            [e.target.name]: e.target.value
        });

    };


    const handleRegister = (e) => {

        e.preventDefault();

        if (
            !formData.name ||
            !formData.rollNumber ||
            !formData.email ||
            !formData.password ||
            !formData.confirmPassword
        ) {

            alert("Please fill all the fields.");

            return;
        }


        if (
            formData.password !==
            formData.confirmPassword
        ) {

            alert("Passwords do not match.");

            return;
        }


        alert("Student registration successful!");

        navigate("/student");
    };


    return (

        <div className="signup-page">

            <div className="signup-card">

                <h2>
                    Student Registration
                </h2>


                <p className="signup-intro">
                    Create your EduLentra student account
                </p>


                <form
                    onSubmit={handleRegister}
                >

                    <input
                        type="text"
                        name="name"
                        placeholder="Full Name"
                        value={formData.name}
                        onChange={handleChange}
                    />


                    <input
                        type="text"
                        name="rollNumber"
                        placeholder="Roll Number"
                        value={formData.rollNumber}
                        onChange={handleChange}
                    />


                    <input
                        type="email"
                        name="email"
                        placeholder="Email ID"
                        value={formData.email}
                        onChange={handleChange}
                    />


                    <input
                        type="password"
                        name="password"
                        placeholder="Create Password"
                        value={formData.password}
                        onChange={handleChange}
                    />


                    <input
                        type="password"
                        name="confirmPassword"
                        placeholder="Confirm Password"
                        value={formData.confirmPassword}
                        onChange={handleChange}
                    />


                    <button
                        type="submit"
                    >
                        Create Account
                    </button>

                </form>


                <p className="account-text">

                    Already have an account?

                    <button
                        className="login-link"
                        onClick={() => navigate("/student")}
                    >
                        Login
                    </button>

                </p>


                <button
                    type="button"
                    className="back-login-btn"
                    onClick={() => navigate("/student")}
                >
                    ← Back to Login
                </button>

            </div>

        </div>
    );
}

export default StudentSignup;