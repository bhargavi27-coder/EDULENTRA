import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Home";
import About from "./About";
import Highlights from "./Highlights";
import Login from "./Login";
import Contact from "./Contact";

import Role from "./Role";

import StudentLogin from "./StudentLogin";
import StudentSignup from "./StudentSignup";

import Faculty from "./Faculty";
import Hod from "./Hod";
import Admin from "./Admin";


function LandingPage() {
    return (
        <>
            <Home />
            <About />
            <Highlights />
            <Login />
            <Contact />
        </>
    );
}


function Mainc() {
    return (

        <Router>

            <Routes>

                {/* HOME PAGE */}

                <Route
                    path="/"
                    element={<LandingPage />}
                />


                {/* ROLE SELECTION PAGE */}

                <Route
                    path="/roles"
                    element={<Role />}
                />


                {/* STUDENT LOGIN */}

                <Route
                    path="/student-login"
                    element={<StudentLogin />}
                />


                {/* STUDENT SIGNUP */}

                <Route
                    path="/student-signup"
                    element={<StudentSignup />}
                />


                {/* FACULTY */}

                <Route
                    path="/faculty"
                    element={<Faculty />}
                />


                {/* HOD */}

                <Route
                    path="/hod"
                    element={<Hod />}
                />


                {/* ADMIN */}

                <Route
                    path="/admin"
                    element={<Admin />}
                />

            </Routes>

        </Router>

    );
}


export default Mainc;