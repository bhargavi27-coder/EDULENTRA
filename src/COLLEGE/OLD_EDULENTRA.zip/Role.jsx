import React from "react";
import { Link } from "react-router-dom";
import "./Role.css";

function Role() {

    return (

        <div className="role-page">

            <h1 className="role-title">
                Choose Your Role
            </h1>

            <p className="role-subtitle">
                Select your portal to continue
            </p>


            <div className="role-container">


                {/* STUDENT */}

                <Link
                    to="/student"
                    className="role-card"
                >

                    <div className="role-icon">
                        📖
                    </div>

                    <h2>
                        Student
                    </h2>

                    <p>
                        Learning Portal
                    </p>

                </Link>


                {/* FACULTY */}

                <Link
                    to="/faculty"
                    className="role-card"
                >

                    <div className="role-icon">
                        🧑‍🏫
                    </div>

                    <h2>
                        Faculty
                    </h2>

                    <p>
                        Teaching Portal
                    </p>

                </Link>


                {/* HOD */}

                <Link
                    to="/hod"
                    className="role-card"
                >

                    <div className="role-icon">
                        📦
                    </div>

                    <h2>
                        HOD
                    </h2>

                    <p>
                        Department Portal
                    </p>

                </Link>


                {/* ADMIN */}

                <Link
                    to="/admin"
                    className="role-card"
                >

                    <div className="role-icon">
                        💻
                    </div>

                    <h2>
                        Admin
                    </h2>

                    <p>
                        Management Portal
                    </p>

                </Link>

            </div>

        </div>
    );
}

export default Role;